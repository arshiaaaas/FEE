import React from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const products = [
  { name: "Wireless Headphones", price: "₹1,499", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500" },
  { name: "Smart Watch", price: "₹2,999", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500" },
  { name: "Running Shoes", price: "₹1,999", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500" },
  { name: "Backpack", price: "₹899", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500" },
  { name: "Sunglasses", price: "₹699", image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500" },
  { name: "Camera", price: "₹4,999", image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500" }
];

function App() {
  return (
    <div className="app">
      <h1>My Store</h1>
      <p className="subtitle">Choose your favourite products</p>

      <div className="products">
        {products.map((product) => (
          <div className="card" key={product.name}>
            <img src={product.image} alt={product.name} />
            <h2>{product.name}</h2>
            <h3>{product.price}</h3>
            <button>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
