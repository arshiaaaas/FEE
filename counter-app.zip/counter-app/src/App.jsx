import { useState } from "react";

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="container">
      <div className="counter">
        <h1>Counter</h1>
        <h2>{count}</h2>
        <div className="grid">
          <button onClick={() => setCount(count + 1)}>+1</button>
          <button onClick={() => setCount(count - 1)}>-1</button>
          <button onClick={() => setCount(count + 2)}>+2</button>
          <button onClick={() => setCount(count + 5)}>+5</button>
        </div>
        <button className="reset" onClick={() => setCount(0)}>Reset</button>
      </div>
    </div>
  );
}

export default App;
